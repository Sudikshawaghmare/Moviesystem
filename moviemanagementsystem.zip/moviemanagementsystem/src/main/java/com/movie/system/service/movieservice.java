package com.movie.system.service;

import java.util.List;

import com.movie.system.entity.movie;


public interface movieservice {
	
 List<movie> Getallmovie();
 
 movie savemovie (movie movie);
 
 movie getmovieById(int Srno);
 
 void deletemovieById(int Srno);
 
}
