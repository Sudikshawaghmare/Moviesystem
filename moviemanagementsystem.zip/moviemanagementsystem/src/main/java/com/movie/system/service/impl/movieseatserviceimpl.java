package com.movie.system.service.impl;

public class movieseatserviceimpl {

}
