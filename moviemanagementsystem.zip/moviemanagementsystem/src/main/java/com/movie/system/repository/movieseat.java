package com.movie.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface movieseat extends JpaRepository<movieseat, Integer>{
	
	

}
