package com.movie.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.system.entity.movie;


public interface movierepository extends JpaRepository<movie, Integer>{
	


}
