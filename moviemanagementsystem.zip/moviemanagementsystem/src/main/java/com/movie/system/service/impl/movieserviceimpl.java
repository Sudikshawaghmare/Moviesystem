package com.movie.system.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.movie.system.entity.movie;
import com.movie.system.repository.movierepository;
import com.movie.system.service.movieservice;

@Service
public class movieserviceimpl implements movieservice{
	

	private movierepository movierepo;
	
	
	public movieserviceimpl(movierepository movierepo) {
		super();
		this.movierepo = movierepo;
	}


	@Override
	public List<movie> Getallmovie() {
	
		return movierepo.findAll();	
	}


	@Override
	public movie savemovie(movie movie) {
		
		return movierepo.save(movie);
	}


	@Override
	public movie getmovieById(int Srno) {
		
		return movierepo.findById(Srno).get();
	}


	@Override
	public void deletemovieById(int Srno) {
	
		movierepo.deleteById(Srno);
	}

}
