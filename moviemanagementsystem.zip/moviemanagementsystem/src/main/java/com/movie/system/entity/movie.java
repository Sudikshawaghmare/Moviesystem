package com.movie.system.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "slw")
public class movie {
	
 @Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Srno;

   @Column (name="Name", nullable=false)
	private String Name;
  
   @Column (name="MovieName")
	private String Moviename;
   
    @Column (name="Noofticket")
	private int Noofticket;
   
   @Column (name="Price")
	private int Price;
   
   @Column (name="TicketMode")
   private String TicketMode;
   
   @Column (name="Seatno")
   private int Seatno;
   
   @Column (name="Mobileno")
   private long Mobileno;
   
   @Column (name="Paymentmode")
   private String Paymentmode;

public int getSrno() {
	return Srno;
}

public void setSrno(int srno) {
	Srno = srno;
}

public String getName() {
	return Name;
}

public void setName(String name) {
	Name = name;
}

public String getMoviename() {
	return Moviename;
}

public void setMoviename(String moviename) {
	Moviename = moviename;
}

public int getNoofticket() {
	return Noofticket;
}

public void setNoofticket(int noofticket) {
	Noofticket = noofticket;
}

public int getPrice() {
	return Price;
}

public void setPrice(int price) {
	Price = price;
}

public String getTicketMode() {
	return TicketMode;
}

public void setTicketMode(String ticketMode) {
	TicketMode = ticketMode;
}

public int getSeatno() {
	return Seatno;
}

public void setSeatno(int seatno) {
	Seatno = seatno;
}

public long getMobileno() {
	return Mobileno;
}

public void setMobileno(long mobileno) {
	Mobileno = mobileno;
}

public String getPaymentmode() {
	return Paymentmode;
}

public void setPaymentmode(String paymentmode) {
	Paymentmode = paymentmode;
}

public movie(String name, String moviename, int noofticket, int price, String ticketMode, int seatno,
		long mobileno, String paymentmode) {
	super();
	Name = name;
	Moviename = moviename;
	Noofticket = noofticket;
	Price = price;
	TicketMode = ticketMode;
	Seatno = seatno;
	Mobileno = mobileno;
	Paymentmode = paymentmode;
}
      
public movie() {   
 


}
}
   
		