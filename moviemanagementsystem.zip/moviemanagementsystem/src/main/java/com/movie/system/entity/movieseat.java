package com.movie.system.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name="seatno")
public class movieseat {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long srno;

	 @Column (name="seatnumber", nullable=false)
    private String seatnumber;
       
   @Column (name="isAvailable")
    private boolean isAvailable;


    
    public Long getId() {
	return srno;
}


public void setId(Long srno) {
	this.srno = srno;
}


public String getSeatnumber() {
	return seatnumber;
}


public void setSeatnumber(String seatnumber) {
	this.seatnumber = seatnumber;
}


public boolean isAvailable() {
	return isAvailable;
}


public void setAvailable(boolean isAvailable) {
	this.isAvailable = isAvailable;
}


	public movieseat(String seatnumber, boolean isAvailable) {
	super();

	this.seatnumber = seatnumber;
	this.isAvailable = isAvailable;
}


	public movieseat() {
       
    }

	
	
}
