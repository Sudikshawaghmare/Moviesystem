package com.movie.system.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.movie.system.entity.movie;
import com.movie.system.service.movieservice;

@Controller
public class moviecontroller {
	
	private movieservice movieser;

	public moviecontroller(movieservice movieser) {
		super();
		this.movieser = movieser;
	}
	

	public class MovieController {
	    // ...

		@GetMapping("/home")
	    public String showEntryPage() {
	        return "homepage";
	    }

	    // ...
	}

	
		
	@GetMapping("/Getmovie")
	public String Getmovie (Model mod)
	{
		mod.addAttribute("movie", movieser.Getallmovie());
		return "movie";
		
	}
	
	@GetMapping("/movie/new")
    public String createhospitalFrom(Model mod)
    {
  	  movie movie = new movie();
  	  mod.addAttribute("movie",movie);
      return "create_movie";
    }
    
    @PostMapping("/movie/save")
    public String savemovie(@ModelAttribute ("movie") movie movie) 
    {
       movieser.savemovie (movie);
       return "redirect:/Getmovie";
}
    
    @GetMapping("/movie/edit/{Srno}")
    public String  editmovieForm(@PathVariable int Srno , Model mod)
    
    {
    	mod.addAttribute("movie",movieser.getmovieById(Srno));
    	return "edit_movie";
    }
    
    //update data
   @PostMapping("/movie/update/{Srno}")
   public String updatemovie (@PathVariable int Srno , @ModelAttribute("movie") movie mov , Model mod)  
   {
	   movie existingM = movieser.getmovieById(Srno);
	   existingM.setSrno(Srno);
	   existingM.setName(mov.getName());
	   existingM.setMoviename(mov.getMoviename());
	   existingM.setNoofticket(mov.getNoofticket());
	   existingM.setPrice(mov.getPrice());
	   existingM.setTicketMode(mov.getTicketMode());
	   existingM.setSeatno(mov.getSeatno());
	   existingM.setMobileno(mov.getMobileno());
	   existingM.setPaymentmode(mov.getPaymentmode());
	   
	   movieser.savemovie(existingM);
	   return "redirect:/Getmovie"; 
   }
    //Delete Data
   @GetMapping("/movie/delete/{Srno}")
   public String deletemovie (@PathVariable int Srno )
		   {
	   movieser.deletemovieById(Srno);
	   return "redirect:/Getmovie";
    
}
}

