package com.movie.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviemanagementsystemApplication {

		public static void main (String[] args) {
			SpringApplication.run(MoviemanagementsystemApplication.class, args);
		
	
	}
 
}
 