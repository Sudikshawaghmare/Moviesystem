package com.movie.system.service;

public interface movieseatservice {

}
